﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","es",{title:"Información del Elemento",dialogName:"Nombre de la ventana de diálogo",tabName:"Nombre de la pestaña",elementId:"ID del Elemento",elementType:"Tipo del elemento"});