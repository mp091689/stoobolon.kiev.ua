<?php

return [

    'title' => 'Общие настройки сайта',
    'edit_fields' => [
        'site_name' => [
            'title' => 'Name',
            'type' => 'text',
        ],
        'maps_code' => [
            'title' => 'Map',
            'type' => 'textarea',
        ],
    ],

];